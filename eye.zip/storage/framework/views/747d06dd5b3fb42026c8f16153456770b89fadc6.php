<div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade <?php if($template == 1): ?> show active <?php endif; ?> pb-3" id="nav-profile" role="tabpanel"
        aria-labelledby="nav-profile-tab">
        <h1 class="fb-label-login">LOGIN</h1>
        <div class="row pt-3">
            <div class="col-12">
                <label class="fb-label-input">
                    E-MAIL * :
                </label>
                <input type="email" wire:change.debounce.750ms='checkEmail()' wire:model='email' class="fb-input"
                    name="email" required id="email" placeholder="Email">
                <input type="hidden" name="score" value="<?php echo e($score); ?>">
                <?php if(!empty($emailError)): ?>
                    <div>
                        <span class="bg-danger" style="font-family: 'Montserrat';font-weight: 500;font-size: 10pt;"><?php echo e($emailError); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row pt-3">
            <div class="col-6">
                <label class="fb-label-input">
                    FIRST NAME :
                </label><br>
                <input type="text" class="fb-input" name="name" value="<?php echo e($name); ?>" wire:model='name'
                    placeholder="First Name">
            </div>
            <div class="col-6">
                <label class="fb-label-input">
                    LAST NAME :
                </label>
                <input type="text" class="fb-input" name="lastname" wire:model='lastname' value="<?php echo e($lastname); ?>"
                    placeholder="Last Name">
            </div>
        </div>
        <div class="row pt-3">
            <div class="col-6">
                <label class="fb-label-input">
                    NICKNAME * :
                </label><br>
                <input type="text" wire:change.debounce.750ms='checkNickname()' wire:model='nickname'
                    class="fb-input" name="nickname" value="<?php echo e($nickname); ?>" required id="nickname"
                    placeholder="Nickname">
                <?php if(!empty($nicknameError)): ?>
                    <span class="bg-danger" style="font-family: 'Montserrat';font-weight: 500;font-size: 10pt;"><?php echo e($nicknameError); ?></span>
                <?php endif; ?>
            </div>
            <div class="col-6">
                <label class="fb-label-input">
                    AGE :
                </label>
                <input type="number" class="fb-input" name="age" value="<?php echo e($age); ?>" placeholder="Age"
                    wire:model='age'>
            </div>
        </div>
        <div class="d-flex justify-content-center row py-4">
            <button class="btn col-5" id="button-next-default" wire:click="checkTemplate('2')" type="button"
                <?php if($email == null || $nickname == null || $emailError != '' || $nicknameError != ''): ?> disabled <?php endif; ?>>
                <img src="<?php echo e(asset('asset/images/etc/next_default.png')); ?>" class="image-start-game">
            </button>
            <button class="btn col-5" id="button-next-clicked" wire:click="checkTemplate('2')" type="button"
                <?php if($email == null || $nickname == null || $emailError != '' || $nicknameError != ''): ?> disabled <?php endif; ?>>
                <img src="<?php echo e(asset('asset/images/etc/next_clicked.png')); ?>" class="image-start-game">
            </button>
            <div class="d-flex justify-content-center mt-2" style="font-size:.75rem; font-weight:300">
                * = mandatory
            </div>
        </div>
    </div>
    <div class="tab-pane fade <?php if($template == 2): ?> show active <?php endif; ?>" id="nav-player" role="tabpanel"
        aria-labelledby="nav-player-tab">
        <div class="row d-flex justify-content-center">
            <h1 class="fb-label-login">LOCKER ROOM</h1>
            <div class="col-lg-12 pb-3">
                <label class="pb-2 fb-label-input">Choose Team</label><br>
                <select name="player_team" class="fb-select" wire:model="player_team" wire:change="changeTeam()"
                    required>
                    <?php $__currentLoopData = $all_data_teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name_team => $data_team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($name_team == $player_team): echo 'selected'; endif; ?> id="<?php echo e($name_team); ?>">
                            <?php echo e($name_team); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-12">
                <?php if($custom_template == false): ?>
                    <label class="pb-2 fb-label-input">Choose Player</label><br>
                    <div class="row">
                        <div class="col-12 pb-2">
                            <select name="player_name" class="fb-select" id="player-option" required>
                                <?php $__currentLoopData = $all_data_teams[$player_team]['player-team']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($key == $player_name): echo 'selected'; endif; ?> value="<?php echo e($key); ?>">
                                        <?php echo e(str_replace('-', ' ', $value)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <button class="btn btn-primary" id="button-custom" type="button"
                                style="border-radius: 20px!important"
                                wire:click="changePlayerName('custom')">Custom</button>
                        </div>
                    </div>
                <?php else: ?>
                    <label class="pb-2 fb-label-input">Custom Player</label><br>
                    <div class="row">
                        <div class="col-12 pb-2">
                            <div class="row">
                                <div class="col-3">
                                    <input type="number" name="number_custom" class="fb-input" min="1"
                                        placeholder="No" value="<?php echo e($number_custom); ?>" required>
                                </div>
                                <div class="col-9">
                                    <input type="text" name="name_custom" class="fb-input" placeholder="Name"
                                        value="<?php echo e($name_custom); ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <button class="btn btn-secondary" type="button" style="border-radius: 20px!important"
                                wire:click="changePlayerName('cancel')">Choose</button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="text-center py-3">
            <h5 class="fb-label-input" style="font-size: 13pt!important">Choose Shirt</h5>
        </div>
        <div class="container-carousel">
            <?php $no = 1; ?>
            <?php $__currentLoopData = $all_data_teams[$player_team]['shirt-team']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($player_shirt != null): ?>
                    <input type="radio" id="item-<?php echo e($no); ?>" <?php if($key == $player_shirt): echo 'checked'; endif; ?>
                        name="player_shirt" value="<?php echo e($key); ?>">
                <?php else: ?>
                    <input type="radio" id="item-<?php echo e($no); ?>" <?php if($no == 1): echo 'checked'; endif; ?>
                        name="player_shirt" value="<?php echo e($key); ?>">
                <?php endif; ?>
                <?php $no++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $no = 1; ?>
            <div class="cards">
                <?php $__currentLoopData = $all_data_teams[$player_team]['shirt-team']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="card" for="item-<?php echo e($no); ?>" id="song-<?php echo e($no); ?>">
                        <img src="<?php echo e(asset('asset/images/shirt/')); ?>/<?php echo e($value); ?>" class="shirt-image">
                    </label>
                    <?php $no++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="d-flex justify-content-center row py-2">
            <button class="btn col-5" id="button-back-default" wire:click="checkTemplate('1')" type="button">
                <img src="<?php echo e(asset('asset/images/etc/button_back_default.png')); ?>" class="image-start-game">
            </button>
            <button class="btn col-5" id="button-back-clicked" wire:click="checkTemplate('1')" type="button">
                <img src="<?php echo e(asset('asset/images/etc/button_back_clicked.png')); ?>" class="image-start-game">
            </button>
            <button class="btn col-5" id="button-start-default" wire:click="checkTemplate('2')" type="submit">
                <img src="<?php echo e(asset('asset/images/etc/button_start_default.png')); ?>" class="image-start-game">
            </button>
            <button class="btn col-5" id="button-start-clicked" wire:click="checkTemplate('2')" type="submit">
                <img src="<?php echo e(asset('asset/images/etc/button_start_clicked.png')); ?>" class="image-start-game">
            </button>
        </div>
    </div>

    <div id="fb-loading">
        <label class="fb-label-input">
            Loading...
        </label>
        <div class="lds-ring">
            <div></div>
        </div>
    </div>
</div>
<?php /**PATH /home/rozin/Documents/UnusualDope/UnusualDope/EYE/resources/views/livewire/registration-form.blade.php ENDPATH**/ ?>