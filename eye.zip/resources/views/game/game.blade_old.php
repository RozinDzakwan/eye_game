<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>EYE Sport Football League</title>
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <meta name="generator" content="Scirra Construct">
    <meta name="author" content="Lodhi Bangash">
    <meta name="description" content="Penalty kick game">
    <link rel="manifest" href="appmanifest.json">
    <link rel="apple-touch-icon" sizes="256x165" href="icons/icon-256.png">
    <link rel="icon" type="image/png" href="icons/icon-256.png">
    <link rel="stylesheet" href="{{ asset('style.css') }}">
</head>

<body>
    <script>
        let gameData = '{!! $data !!}';
        if (location.protocol.substr(0, 4) === "file") {
            alert(
                "Web exports won't work until you upload them. (When running on the file: protocol, browsers block many features from working for security reasons.)"
            );
        }
    </script>
    <script src="{{ asset('init.js') }}"></script>
    <script src="{{ asset('box2d.wasm.js') }}"></script>
    <noscript>
        <div id="notSupportedWrap">
            <h2 id="notSupportedTitle">This content requires JavaScript</h2>
            <p class="notSupportedMessage">JavaScript appears to be disabled. Please enable it to view this content.</p>
        </div>
    </noscript>
    <script src="{{ asset('scripts/supportcheck.js') }}"></script>
    <script src="{{ asset('scripts/offlineclient.js') }}" type="module"></script>
    <script src="{{ asset('scripts/main.js') }}" type="module"></script>
    <script src="{{ asset('scripts/register-sw.js') }}" type="module"></script>
</body>

</html>
