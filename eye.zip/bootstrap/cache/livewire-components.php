<?php return array (
  'leaderboard' => 'App\\Http\\Livewire\\Leaderboard',
  'registration-form' => 'App\\Http\\Livewire\\RegistrationForm',
);